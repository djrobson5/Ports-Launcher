@echo off
setlocal EnableDelayedExpansion
color 60

set "ROOT=%~dp0"
set "EXE=%ROOT%truncate.exe"
set "IN=%ROOT%input"
set "OUT=%ROOT%output"

if not exist "%IN%" mkdir "%IN%"
if not exist "%OUT%" mkdir "%OUT%"

if not exist "%EXE%" (
    echo truncate.exe introuvable a cote de ce .bat.
    echo truncate.exe not found next to this .bat.
    pause
    exit /b 1
)

:menu
cls
echo ================================================================
echo   Truncate
echo   Depose un fichier dans input\, choisis un mode ci-dessous.
echo   Drop a file into input\, pick a mode below.
echo   Le resultat va dans output\, input\ reste intact.
echo   The result goes to output\, input\ stays untouched.
echo ================================================================
echo   1. Afficher la taille actuelle       / Show current size
echo   2. Definir une taille exacte         / Set an exact size
echo   3. Rogner le debut (skip)            / Trim from the start
echo   4. Rogner la fin (trim-end)          / Trim from the end
echo   5. Rogner les deux extremites        / Crop both ends
echo   6. Decaler + redimensionner          / Shift + resize
echo   0. Quitter                           / Exit
echo ================================================================
set /p "choice=Choix / Choice: "

if "%choice%"=="0" exit /b 0
if "%choice%"=="1" goto mode_status
if "%choice%"=="2" goto mode_size
if "%choice%"=="3" goto mode_skip
if "%choice%"=="4" goto mode_trim
if "%choice%"=="5" goto mode_crop
if "%choice%"=="6" goto mode_shift
echo Choix invalide / Invalid choice.
pause
goto menu

:pick_file
set "SRC="
set "count=0"
for %%F in ("%IN%\*") do (
    set /a count+=1
    set "file!count!=%%~nxF"
)
if "%count%"=="0" (
    echo Aucun fichier dans input\. Depose un fichier puis relance.
    echo No file in input\. Drop a file then rerun.
    pause
    goto :eof
)
echo.
echo Fichiers disponibles / Available files:
for /l %%i in (1,1,%count%) do echo   %%i. !file%%i!
set /p "fidx=Numero du fichier / File number: "
if not defined file%fidx% (
    echo Choix invalide / Invalid choice.
    pause
    goto :eof
)
set "SRC=!file%fidx%!"
copy /y "%IN%\%SRC%" "%OUT%\%SRC%" >nul
goto :eof

:mode_status
call :pick_file
if not defined SRC goto menu
"%EXE%" "%OUT%\%SRC%"
pause
goto menu

:mode_size
call :pick_file
if not defined SRC goto menu
set /p "size=Taille cible, ex 2G / Target size, e.g. 2G: "
"%EXE%" "%OUT%\%SRC%" %size%
pause
goto menu

:mode_skip
call :pick_file
if not defined SRC goto menu
set /p "skip=Octets a retirer au debut, ex 1K / Bytes to trim from start, e.g. 1K: "
"%EXE%" "%OUT%\%SRC%" --skip %skip%
pause
goto menu

:mode_trim
call :pick_file
if not defined SRC goto menu
set /p "trim=Octets a retirer a la fin, ex 1K / Bytes to trim from end, e.g. 1K: "
"%EXE%" "%OUT%\%SRC%" --trim-end %trim%
pause
goto menu

:mode_crop
call :pick_file
if not defined SRC goto menu
set /p "skip=Octets a retirer au debut, ex 1K / Bytes to trim from start, e.g. 1K: "
set /p "trim=Octets a retirer a la fin, ex 1K / Bytes to trim from end, e.g. 1K: "
"%EXE%" "%OUT%\%SRC%" --skip %skip% --trim-end %trim%
pause
goto menu

:mode_shift
call :pick_file
if not defined SRC goto menu
set /p "size=Taille cible, ex 1T / Target size, e.g. 1T: "
set /p "skip=Decalage depuis le debut, ex 777 / Offset from start, e.g. 777: "
"%EXE%" "%OUT%\%SRC%" %size% --skip %skip%
pause
goto menu
